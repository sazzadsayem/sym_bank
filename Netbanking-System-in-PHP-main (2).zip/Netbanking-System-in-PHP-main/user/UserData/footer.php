</div>



<footer class="footer">

    <!-- Modal -->
    <div class="modal fade" id="purchaseCode" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Try Premium</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p class="text-danger"><strong>Some features of the project are not working. Because you are using a demo version of the project. Purchase the project at an affordable price to unlock all features</strong></p>
                    <h5>Contact Developer</h5>
                    <p> <strong> Telegram Id: </strong> @Digambar4u</p>
                    <p><strong>Email: </strong> skytechcreators@gmail.com</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">View Pricing</button>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row text-muted">
            <div class="col-6 text-left">
                <p class="mb-0">
                    <a href="../../index.php" class="text-muted"><strong><?php echo BANKNAME ?>
                        </strong></a> &copy
                </p>
            </div>
            <div class="col-6 text-right">
                <ul class="list-inline">
                    <!-- <li class="footer-item">
                        <a class="text-muted" href="#">Support</a>
                    </li>
                    <li class="footer-item">
                        <a class="text-muted" href="#">Help Center</a>
                    </li> -->
                    <li class="footer-item">
                        <a class="text-muted" href="../../pages/privacypolicy.php">Privacy</a>
                    </li>
                    <li class="footer-item">
                        <a class="text-muted" href="../../pages/terms.php">Terms</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>

</div>
</div>
<!-- /#page-content-wrapper -->

</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<div class="modal fade" id="purchaseCode" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Try Premium</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="text-danger"><strong>Some features of the project are not working. Because you are using a demo version of the project. Purchase the project at an affordable price to unlock all features</strong></p>
                <h5>Contact Developer</h5>
                <p> <strong> Telegram Id: </strong> @Digambar4u</p>
                <p><strong>Email: </strong> skytechcreators@gmail.com</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <a href="https://skytech4u.github.io/skytech/" role="button" type="button" class="btn btn-primary">View Pricing</a>
            </div>
        </div>
    </div>
</div>

<script>
    $(window).on('load', function() {
        $('#purchaseCode').modal('show');
    });
</script>
<!-- javascript -->