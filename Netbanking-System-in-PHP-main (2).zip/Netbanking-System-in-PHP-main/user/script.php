<!-- Sweet Alert Script -->

<script src="../assets/js/sweetalert.min.js"></script>